import os
import getpass
import pandas as pd
from sentence_transformers import SentenceTransformer
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_mistralai import ChatMistralAI
from langchain_core.messages import HumanMessage
from langchain.schema import Document

# Text cleaning function
def clean_text(text):
    text = text.lower()
    text = text.replace('\n', ' ')
    text = text.replace('\t', ' ')
    text = text.replace(',', ' ')
    text = text.replace('.', ' ')
    text = text.replace('?', ' ')
    text = text.replace('!', ' ')
    text = text.replace(':', ' ')
    text = text.replace(';', ' ')
    text = text.replace('"', ' ')
    text = text.replace("'", ' ')
    text = text.replace('(', ' ')
    text = text.replace(')', ' ')
    text = text.replace('[', ' ')
    text = text.replace(']', ' ')
    text = text.replace('{', ' ')
    text = text.replace('}', ' ')
    text = text.replace('<', ' ')
    text = text.replace('>', ' ')
    text = text.replace('/', ' ')
    text = text.replace('\\', ' ')
    text = text.replace('-', ' ')
    text = text.replace('_', ' ')
    text = text.replace('=', ' ')
    text = text.replace('+', ' ')
    text = text.replace('*', ' ')
    text = text.replace('#', ' ')
    text = text.replace('$', ' ')
    text = text.replace('%', ' ')
    text = text.replace('^', ' ')
    text = text.replace('&', ' ')
    text = text.replace('|', ' ')
    text = text.replace('~', ' ')
    text = text.replace('`', ' ')
    text = text.replace('  ', ' ')
    return text

# Data cleaning function to process CSV rows
def clean_data(data):
    documents = []

    for _, row in data.iterrows():
        # Remove 'Resume_html' if it exists
        row_data = row.drop(labels=['Resume_html'], errors='ignore')
        
        # Create cleaned text string
        cleaned_text = ' '.join([f"{col}: {clean_text(str(val))}" for col, val in row_data.items()])
        documents.append(Document(page_content=cleaned_text))
    
    return documents

# Load and clean CSV data
def load_csv(csv_path, columns_to_remove):
    try:
        # Load CSV data into pandas DataFrame
        data = pd.read_csv(csv_path)
        
        # Remove specified columns
        if columns_to_remove:
            data = data.drop(columns=columns_to_remove, errors='ignore')
        
        # Clean the data
        documents = clean_data(data)
        return documents
    except FileNotFoundError:
        print(f"Error: File {csv_path} not found.")
        return None

# Create Chroma index
def create_chroma_index(documents):
    print("Creating Chroma index. This may take a few moments...")

    # Load embeddings and split documents into chunks
    embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=256, chunk_overlap=0)

    # Split documents into chunks (now using split_documents)
    split_docs = text_splitter.split_documents(documents)

    # Create Chroma vector store
    vector_store = Chroma.from_documents(split_docs, embeddings)

    print(f"Chroma index created successfully with {len(split_docs)} chunks.")
    return vector_store

# Retrieve relevant document chunks
def retrieve_relevant_chunks(query, vector_store, k=3):
    docs = vector_store.similarity_search(query, k=k)
    return [doc.page_content for doc in docs]

# Ask question and retrieve relevant information using RAG
def ask_question_with_rag(query, vector_store, model):
    relevant_chunks = retrieve_relevant_chunks(query, vector_store)
    context = " ".join(relevant_chunks)

    print("Generating response from the model...")
    response = model.invoke([HumanMessage(content=f"{query}\n\nContext: {context}")])
    return response

# Main function
def main():
    os.environ["MISTRAL_API_KEY"] = getpass.getpass(prompt="Enter your Mistral API key: ")
    model = ChatMistralAI(model="mistral-large-latest")

    print("\nWelcome to the CSV-based Chatbot!")
    csv_path = input("Please enter the path to your CSV file: ").strip()

    columns_to_remove = input("Enter columns to remove (comma-separated, or leave empty to keep all): ").strip().split(',')
    columns_to_remove = [col.strip() for col in columns_to_remove if col.strip()]  # Clean up column list

    documents = load_csv(csv_path, columns_to_remove)
    if documents is None:
        return

    vector_store = create_chroma_index(documents)

    print("\nChatbot is ready! You can ask questions based on the CSV content.")
    print("Type 'exit' to end the session.\n")

    while True:
        query = input("You: ").strip()
        if query.lower() in ['exit', 'quit', 'q']:
            print("Thank you for using the chatbot. Goodbye!")
            break

        answer = ask_question_with_rag(query, vector_store, model)
        print(f"Bot: {answer.content}\n")

if __name__ == "__main__":
    main()
